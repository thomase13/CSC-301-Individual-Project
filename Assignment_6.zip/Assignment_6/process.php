<html>
<body>
<?php require_once('RW.php');?>
Thank You. <?php echo $_POST["name"];?> has been entered into our database.<br>

<?php
$name = $_REQUEST['name'];
$gender = $_REQUEST['gender'];
$age = $_REQUEST['age'];
$size = $_REQUEST['size'];
$health = $_REQUEST['health'];
$picture = $_REQUEST['picture'];
?>
<?php echo $name;?> <br>
<?php echo $gender;?> <br>
<?php echo $age;?> <br>
<?php echo $size;?> <br>
<?php echo $health;?> <br>
<img src="<?php echo $picture?>">
<?php
$pArray=[
	[
		'name'=>$name,
		'picture'=>$picture,
		'age'=>$age,
		'gender'=>$gender,
		'size'=>$size,
		'health'=>$health,
	]
]
?>
<br><br>
<?php
ReadWrite::write('data.json', $pArray);
//$companions[] = $pArray;
//$json_string = json_encode($companions);
?>


</body>
</html>